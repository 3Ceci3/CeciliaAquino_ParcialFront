# Instalación

### `npm install`
### `npm start`

# Guía de consignas

En cada uno de los componentes está detallado su funcionamiento y lo que deben resolver. 👌

# Demo del proyecto

Aquí pueden ver una demo del funcionamiento de la aplicación. 👇

![posteosDemo.gif](https://raw.githubusercontent.com/Frontend-III/evaluacion-noviembre-22/main/posteosDemo.gif)
